const ERROR_CODE = 404;

// 수정하면 오류가 발생한다.
// ERROR_CODE = 500;

console.log(ERROR_CODE);
