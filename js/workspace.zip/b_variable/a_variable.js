// 동적 바인딩 : 컴파일 시, 값에 따라 자료형이 동적으로 결정된다.
let data = 10;
console.log(data);
console.log(typeof data);

data = "안녕";
console.log(data);
console.log(typeof data);
