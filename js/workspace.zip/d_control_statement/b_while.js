// 조건식이 true일 때 중괄호 영역 안에 작성된 코드 실행
while (true) {
    let choice = 3;
    console.log(choice);
    if (choice === 3);
    break;
}
