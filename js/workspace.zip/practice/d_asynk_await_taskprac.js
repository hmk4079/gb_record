// 모듈화, async, await, callback
// koreanjson 에서 posts 정보를 전체 가져온 뒤
// userId가 6인 게시글 정보들만 출력하기

// async가 함수 앞에 붙여져있으면, 리턴은 무조건 Promise객체로 감싸진다.
// const postService = (() => {
//     const findPosts = async (UserId, callback) => {
//         //비동기화
//         const response = await fetch("https://koreanjson.com/posts"); // response와 posts에 await를 사용함으로서 비동기화 상태로 만들어준다
//         const posts = await response.json();
//         return callback(UserId, posts);
//     };
//     return { findPosts: findPosts };
// })();

// const getMyPosts = (UserId, posts) => {
//     return posts.filter((post) => post.UserId === UserId);
// };

// const printMyPosts = async () => {
//     const myPosts = await postService.findPosts(6, getMyPosts);
//     console.log(myPosts);
// };

// printMyPosts();

// todos 데이터를 요청한 뒤, userId가 3인 정보 모두 가져오기
// 그 중 userId와 updateAtr과 title 출력하기

const getTodos = (() => {
    const findTodos = async (UserId, callback) => {
        const response = await fetch("https://koreanjson.com/todos");
        const todos = await response.json();
        return callback(UserId, todos);
    };

    return { findTodos: findTodos };
})();

const getMyTodos = (UserId, todos) => {
    return todos.filter((todo) => todo.UserId === UserId);
};

const printMyTodos = async () => {
    const myTodos = await getTodos.findTodos(3, getMyTodos);
    myTodos.forEach(({ UserId, title, updatedAt }) => {
        console.log(`${UserId}: ${title}: ${updatedAt}`);
    });
};

printMyTodos();
