// const promise = new Promise((resolve, reject) => {
//     let check = true;
//     if (check) {
//         resolve("성공!");
//     } else {
//         reject("실패!");
//     }
// });

const truePromise = new Promise((resolve, reject) => {
    let trueCheck = true;
    if (trueCheck) {
        resolve("성공!");
    } else {
        reject("실패!");
    }
});
const falsePromise = new Promise((resolve, reject) => {
    let falseCheck = false;
    if (falseCheck) {
        resolve("성공!");
    } else {
        reject("실패!");
    }
});

truePromise
    .then((result) => {
        console.log(result);
    })
    .catch((result) => {
        console.log(result);
    });

falsePromise
    .then((result) => {
        console.log(result);
    })
    .catch((result) => {
        console.log(result);
    });
