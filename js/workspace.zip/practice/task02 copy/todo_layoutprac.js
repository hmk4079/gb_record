const todoLayout = (() => {
    //postLayout은 리턴이 있기 때문에, 즉 바로 사용했기 때문에 객체이다
    const showToDos = (todos) => {
        const table = document.querySelector("table.todos");
        let text = ``;

        todos.forEach((todo) => {
            text += `<tr>
                        <td><span>${todo.UserId}</span></td>
                        <td>
                            <span ${todo.completed && "class='on'"}>${
                todo.title
            }</span>
                        </td>
                        <td>${todo.completed}</td>
                    </tr>`;
        });

        table.innerHTML = text;
    };

    return { showToDos: showToDos };
})();

// let color = todo.completed ? "green" : "red";
// text += `<tr>
//             <td>${todo.userId}</td>
//             <td style ="color: ${color}">${todo.title}</td>
//         </tr>`;
