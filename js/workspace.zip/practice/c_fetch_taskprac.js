// koreanjson에 posts 정보를 요청한다.
// 전달받은 게시글들 중, id가 짝수인 게시글 아이디와 제목만 출력한다.
// fetch("https://koreanjson.com/posts")
//     .then((response) => response.json())
//     .then((posts) => {
//         posts
//             .filter((post) => post.id % 2 === 0)
//             .forEach((post) => {
//                 console.log(`${post.id}:${post.title}`);
//             });
//     });
// 전달받은 게시글들 중, id가 3의 배수인 게시글 아이디와 제목만 출력한다.
// fetch("https://koreanjson.com/posts")
//     .then((response) => response.json())
//     .then((posts) => {
//         posts
//             .filter((post) => post.id % 3 === 1)
//             .forEach((post) => {
//                 console.log(`${post.id}:${post.title}`);
//             });
//     });
// koreanjson에 todos 정보를 요청한다.
// 전달받은 댓글들 중, userId가 3인 댓글 내용을 출력한다.
// fetch("https://koreanjson.com/todos")
//     .then((response) => response.json())
//     .then((todos) => {
//         todos
//             .filter((todo) => todo.UserId === 3)
//             .forEach((todo) => {
//                 console.log(`${todo.id}:${todo.UserId}:${todo.title}`);
//             });
//     });

// users 정보를 요청한 뒤 city(도시)만 출력
// fetch("https://koreanjson.com/users")
//     .then((response) => response.json())
//     .then((users) => {
//         users.forEach((user) => {
//             console.log(`${user.name}:${user.city}`);
//         });
//     });
