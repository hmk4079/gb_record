package operTest;

public class OperTest5 {
	public static void main(String[] args) {
		int data = 10;
//		data = data + 1;		++data  ++바로뒤에값 +1
//		data += 1;				data++ ++뒤에나오는 변수명에 +1
//		System.out.println(data++);
		System.out.println(++data);
		System.out.println(data);
	}
}
