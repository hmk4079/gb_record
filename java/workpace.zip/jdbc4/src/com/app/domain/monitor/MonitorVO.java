package com.app.domain.monitor;

import java.util.Objects;

public class MonitorVO {
	
		private Long id;
		private String monitorName;
		private String monitorBrand;
		private String monitorHRZ;
		private String MemberID;
		private String createdDate;
		private String updatedDate;
		
		public MonitorVO() {;}

		public MonitorVO(Long id, String monitorName, String monitorBrand, String monitorHRZ, String memberID,
				String createdDate, String updatedDate) {
			super();
			this.id = id;
			this.monitorName = monitorName;
			this.monitorBrand = monitorBrand;
			this.monitorHRZ = monitorHRZ;
			MemberID = memberID;
			this.createdDate = createdDate;
			this.updatedDate = updatedDate;
		}


		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getMonitorName() {
			return monitorName;
		}

		public void setMonitorName(String monitorName) {
			this.monitorName = monitorName;
		}

		public String getMonitorBrand() {
			return monitorBrand;
		}

		public void setMonitorBrand(String monitorBrand) {
			this.monitorBrand = monitorBrand;
		}

		public String getMonitorHRZ() {
			return monitorHRZ;
		}

		public void setMonitorHRZ(String monitorHRZ) {
			this.monitorHRZ = monitorHRZ;
		}

		public String getMemberID() {
			return MemberID;
		}

		public void setMemberID(String memberID) {
			MemberID = memberID;
		}

		public String getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}

		public String getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(String updatedDate) {
			this.updatedDate = updatedDate;
		}

		@Override
		public int hashCode() {
			return Objects.hash(id);
		}
		

		@Override
		public String toString() {
			return "MonitorVO [id=" + id + ", monitorName=" + monitorName + ", monitorBrand=" + monitorBrand
					+ ", monitorHRZ=" + monitorHRZ + ", MemberID=" + MemberID + ", createdDate=" + createdDate
					+ ", updatedDate=" + updatedDate + "]";
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			MonitorVO other = (MonitorVO) obj;
			return Objects.equals(id, other.id);
		}
}