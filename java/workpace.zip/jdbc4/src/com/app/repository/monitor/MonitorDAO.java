package com.app.repository.monitor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.app.domain.monitor.MonitorVO;
import com.app.jdbc4.configuration.Configuration;

public class MonitorDAO{

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	
//		추가하기
	public void insert(MonitorVO monitorVO) {
		String query = "INSERT INTO TBL_MONITOR "
				+ "(ID, MONITOR_NAME, MONITOR_BRAND, MONITOR_HRZ) "
				+ " MEMBER_ID, CREATED_DATE, UPDATED_DATE) "
				+ "VALUES(SEQ_MONITOR, ?, ?, ?, ?) ";
				
				
		
		try {
	         connection = Configuration.getConnection();
	         preparedStatement = connection.prepareStatement(query);
	         preparedStatement.setString(1, monitorVO.getMonitorName());
	         preparedStatement.setString(2, monitorVO.getMonitorBrand());
	         preparedStatement.setString(3, monitorVO.getMonitorHRZ());
	         preparedStatement.setString(4, monitorVO.getMemberID());
	         
	         preparedStatement.executeUpdate();
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            if(preparedStatement != null) {
	               preparedStatement.close();
	            }
	            if(connection != null) {
	               connection.close();
	            }
	         } catch (SQLException e) {
	            throw new RuntimeException();
	         }
	      }
		}
	
//  조회하기
	public MonitorVO select(Long id) {
	      MonitorVO monitorVO = new MonitorVO();
	      String query = "SELECT ID, MONITOR_NAME, MONITOR_BRAND, "
	      		 + " MONITOR_HRZ, MEMBER_ID, CREATED_DATE, UPDATED_DATE "
	    		 + " FROM TBL_MONITOR ";
	      
	      try {
	         connection = Configuration.getConnection();
	         preparedStatement = connection.prepareStatement(query);
	         preparedStatement.setLong(1, id);
	         
	         resultSet = preparedStatement.executeQuery();
	         
	         resultSet.next();
	         monitorVO.setId(resultSet.getLong("ID"));
	         monitorVO.setMonitorName(resultSet.getString("MONITOR_NAME"));
	         monitorVO.setMonitorBrand(resultSet.getString("MONITOR_BRAND"));
	         monitorVO.setMonitorHRZ(resultSet.getString("MONITOR_HRZ"));
	         monitorVO.setMemberID(resultSet.getString("MEMBER_ID"));
	         monitorVO.setCreatedDate(resultSet.getString("CREATE_DATE"));
	         monitorVO.setUpdatedDate(resultSet.getString("UPDATE_DATE"));
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            if(resultSet != null) {
	               resultSet.close();
	            }
	            if(preparedStatement != null) {
	               preparedStatement.close();
	            }
	            if(connection != null) {
	               connection.close();
	            }
	         } catch (SQLException e) {
	            throw new RuntimeException();
	         }
	      }
	      return monitorVO;
	   }
	   
//  수정하기
  public void update(MonitorVO monitorVO) {
     String query = "UPDATE TBL_CAR "
    		 + "SET CAR_NAME=?, CAR_BRAND=?, CAR_TYPE=?, "
    		 + "MEMBER_ID=?, WHERE ID=? ";
     
     try {
        connection = Configuration.getConnection();
        preparedStatement = connection.prepareStatement(query);
        
        connection = Configuration.getConnection();
        preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, monitorVO.getMonitorName());
        preparedStatement.setString(2, monitorVO.getMonitorBrand());
        preparedStatement.setString(3, monitorVO.getMonitorHRZ());
        preparedStatement.setString(4, monitorVO.getMemberID());
        preparedStatement.setLong(5, monitorVO.getId());
        
        preparedStatement.executeUpdate();
        
     } catch (SQLException e) {
        e.printStackTrace();
     } finally {
        try {
           if(preparedStatement != null) {
              preparedStatement.close();
           }
           if(connection != null) {
              connection.close();
           }
        } catch (SQLException e) {
           throw new RuntimeException();
        }
     }
  }
  
//삭제하기
public void delete(Long id) {
   String query = "DELETE FROM TBL_Monitor WHERE ID = ?";
   
   try {
      connection = Configuration.getConnection();
      preparedStatement = connection.prepareStatement(query);
      
      preparedStatement.setLong(1, id);
      
      preparedStatement.executeUpdate();
      
   } catch (SQLException e) {
      e.printStackTrace();
   } finally {
      try {
         if(preparedStatement != null) {
            preparedStatement.close();
         }
         if(connection != null) {
            connection.close();
         }
      } catch (SQLException e) {
         throw new RuntimeException();
      }
   }
}	

//전체 조회하기
public ArrayList<MonitorVO> selectAll() {
 ArrayList<MonitorVO> monitor = new ArrayList<MonitorVO>();
 MonitorVO monitorVO = null;
 String query = "SELECT ID, MONITOR_NAME, MONITOR_BRAND, MONITOR_HRZ, "
       + "MEMBER_ID, FROM TBL_MONITOR";
 
 try {
    connection = Configuration.getConnection();
    preparedStatement = connection.prepareStatement(query);
    
    resultSet = preparedStatement.executeQuery();
    
    if(resultSet.next()) {
       do {
    	   monitorVO = new MonitorVO();
    	   monitorVO.setId(resultSet.getLong("ID"));
    	   monitorVO.setMonitorName(resultSet.getString("MONIOTR_NAME"));
    	   monitorVO.setMonitorBrand(resultSet.getString("MONITOR_BRAND"));
    	   monitorVO.setMonitorHRZ(resultSet.getString("MONITOR_HRZ"));
    	   monitorVO.setMemberID(resultSet.getString("MEMBER_ID"));
    	   monitorVO.setCreatedDate(resultSet.getString("CREATED_DATE"));
	       monitorVO.setUpdatedDate(resultSet.getString("UPDATED_DATE"));
          
          monitor.add(monitorVO);
          
       } while(resultSet.next());
    }
    
 } catch (SQLException e) {
    e.printStackTrace();
 } finally {
    try {
       if(resultSet != null) {
          resultSet.close();
       }
       if(preparedStatement != null) {
          preparedStatement.close();
       }
       if(connection != null) {
          connection.close();
       }
    } catch (SQLException e) {
       throw new RuntimeException();
    }
 }
 return monitor;
}	
	
	
	
	
	
	
}
