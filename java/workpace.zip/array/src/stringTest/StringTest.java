package stringTest;

public class StringTest {
	public static void main(String[] args) {
//		문자열 문자배열이다.
//		String data = "ABC";
//		System.out.println(data.length());
//		System.out.println(data.charAt(0));
//		System.out.println(data.indexOf('B'));
	}
}










