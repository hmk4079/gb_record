package stringTest;

import java.util.Scanner;

public class StringTask {
	public static void main(String[] args) {
//		사용자에게 입력받은 문자열 중 소문자는 모두 대문자로,
//		대문자는 모두 소문자로 변경한다.
		
//		String message = "영어로 문장을 입력해주세요";
//		Scanner sc = new Scanner(System.in);
//		String data = null;
//		String result = "";
//		
//		System.out.println(message);
//		data = sc.nextLine();
//		
//		for (int i = 0; i < data.length(); i++) {
//			char ch = data.charAt(i);
//			if(ch >= 97 && ch <= 122) { // 소문자 검사
//				result += (char)(ch - 32);
//				
//			}
//			else if(ch >= 65 && ch <= 90) { // 대문자 검사
//				result += (char)(ch + 32);
//				
//			}else {
//				result += ch;
//			}
//		}
//		
//		System.out.println(result);
		
//		정수를 한글로 변경한다.
//		입력 예) 1024
//		출력 예) 일공이사
//		String message = "정수 입력: ";
//		Scanner sc = new Scanner(System.in);
//		String data = null;
////		int number = 0;
//		String hangle = "공일이삼사오육칠팔구";
//		String result = "";
//				
//		System.out.println(message);
//		data = sc.next();
//		
//		for (int i = 0; i < data.length(); i++) {
//			result += hangle.charAt(data.charAt(i) - 48);
//		}
//		
//		System.out.println(result);
		
//		number = sc.nextInt();
//		
//		while(number != 0) {
//			result = hangle.charAt(number % 10) + result;
//			number /= 10;
//		}
//		
//		System.out.println(result);
		
//		한글을 정수로 변경한다.
//		입력 예) 일공이사
//		출력 예) 1024
//		String hangle = "공일이삼사오육칠팔구";
//		String message = "정수를 한글로 입력: ";
//		Scanner sc = new Scanner(System.in);
//		String data = null;
//		String temp = "";
//		int result = 0;
//		
//		System.out.println(message);
//		data = sc.next();
//		
//		for (int i = 0; i < data.length(); i++) {
//			temp += hangle.indexOf(data.charAt(i));
//		}
//		
//		result = Integer.parseInt(temp);
//		System.out.println(result);
		
//		아래의 주소에서 "/news"만 분리하여 출력한다.
//		www.naver.com/news
		
//		String data = "www.naver.com/news";
//		int fromIndex = data.indexOf("/");
//		String result = data.substring(fromIndex);
//		
//		System.out.println(result);
	}
}















