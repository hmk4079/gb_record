package castingTest;

public class CastingTest3 {
	public static void main(String[] args) {
		int result = 4;
		
		System.out.println("" + 3);
		System.out.println("1" + 3 + 8);
		System.out.println("1" + (3 + 8));
		System.out.println("1 + 3 = " + result);
	}
}
