package accessTest1;

// Alt + Shift + r: 이름 변경
public class AccessTest1 {
	public static void main(String[] args) {
		Access1 access1 = new Access1();
	}
}
