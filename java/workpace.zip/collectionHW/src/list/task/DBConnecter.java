package list.task;

import java.util.ArrayList;

import list.task.Dress.Dress;
import list.task.epl.EPL;
import list.task.epl.Team;
import list.task.store.AppStore;
import list.task.subway.Subway;

public class DBConnecter {
	public static ArrayList<Dress> dress = new ArrayList<Dress>();
	public static ArrayList<Subway> subways = new ArrayList<Subway>();
	public static ArrayList<Team> teams =  new ArrayList<Team>();
	public static ArrayList<AppStore> apps = new ArrayList<AppStore>();
}

