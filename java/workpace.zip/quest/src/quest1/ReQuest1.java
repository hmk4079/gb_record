package quest1;

public class ReQuest1 {
	public static void  main(String[] args) {
//		1) 1부터 100사이의 모든 정수를 한 줄에 10개씩 출력하는 프로그램 만들기
		String space = "\n"; 
		int[]arData = new int[100];
		for(int i = 0;i < 100; i++) {
				arData[i] = i+1;	
				System.out.print(arData[i]+"\t");	
//				if()
					
		}
	
				
			
		
		
		
		
		
		
		
		
		
		
//		2) 전체 구구단을 다음과 같은 모습으로 출력하는 프로그램 만들기
		
		
		

//		3) 별 찍기(이중 for문)



//		4) 정수를 입력받아 입력 받은 정수가 1~10사이의 정수라면 입력받은 정수 출력




//		5) 사용자로부터 숫자를 입력 받고 1부터 입력 받은 값까지의 합을 구하고









	}		//메소드
}		//클래스
