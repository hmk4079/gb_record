package com.app.post.domain;

import java.util.Objects;

public class CarVO {
	
		private Long id;
		private String carName;
		private String carBrand;
		private String carType;
		private String createdDate;
		private String updatedDate;
		private String MemberID;
		
		public CarVO() {;}

		
		public CarVO(Long id, String carName, String carBrand, String carType, String createdDate, String updatedDate,
				String memberID) {
			super();
			this.id = id;
			this.carName = carName;
			this.carBrand = carBrand;
			this.carType = carType;
			this.createdDate = createdDate;
			this.updatedDate = updatedDate;
			this.MemberID = memberID;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getCarName() {
			return carName;
		}

		public void setCarName(String carName) {
			this.carName = carName;
		}

		public String getCarBrand() {
			return carBrand;
		}

		public void setCarBrand(String carBrand) {
			this.carBrand = carBrand;
		}

		public String getCarType() {
			return carType;
		}

		public void setCarType(String carType) {
			this.carType = carType;
		}

		public String getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}

		public String getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(String updatedDate) {
			this.updatedDate = updatedDate;
		}

		public String getMemberID() {
			return MemberID;
		}

		public void setMemberID(String memberID) {
			this.MemberID = memberID;
		}

		@Override
		public String toString() {
			return "carVO [id=" + id + ", carName=" + carName + ", carBrand=" + carBrand + ", carType=" + carType
					+ ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + ", memberID=" + MemberID + "]";
		}

		@Override
		public int hashCode() {
			return Objects.hash(id);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CarVO other = (CarVO) obj;
			return Objects.equals(id, other.id);
		}


		
		
}
