package com.app.post.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.app.jdbc3.configuration.Configuration;
import com.app.post.domain.CarVO;

public class CarDAO{

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	
//		추가하기
	public void insert(CarVO carVO) {
		String query = "INSERT INTO TBL_CAR "
				+ "(ID, CAR_NAME, CAR_BRAND, CAR_TYPE, MEMBER_ID, CREATED_DATE, UPDATED_DATE) "
				+ "VALUES(SEQ_CAR.NEXTVAL, ?, ?, ?, ?) ";
				
				
		
		try {
	         connection = Configuration.getConnection();
	         preparedStatement = connection.prepareStatement(query);
	         preparedStatement.setString(1, carVO.getCarName());
	         preparedStatement.setString(2, carVO.getCarBrand());
	         preparedStatement.setString(3, carVO.getCarType());
	         preparedStatement.setString(4, carVO.getMemberID());
	         
	         preparedStatement.executeUpdate();
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            if(preparedStatement != null) {
	               preparedStatement.close();
	            }
	            if(connection != null) {
	               connection.close();
	            }
	         } catch (SQLException e) {
	            throw new RuntimeException();
	         }
	      }
		}
	
//  조회하기
	public CarVO select(Long id) {
	      CarVO carVO = new CarVO();
	      String query = "SELECT ID, CAR_NAME, CAR_BRAND, "
					+ "CAR_TYPE, MEMBER_ID "
					+ "FROM TBL_POST "
					+ "WHERE ID = ?";
	      
	      try {
	         connection = Configuration.getConnection();
	         preparedStatement = connection.prepareStatement(query);
	         preparedStatement.setLong(1, id);
	         
	         resultSet = preparedStatement.executeQuery();
	         
	         resultSet.next();
	         carVO.setId(resultSet.getLong("ID"));
	         carVO.setCarName(resultSet.getString("CAR_NAME"));
	         carVO.setCarBrand(resultSet.getString("CAR_BRAND"));
	         carVO.setCarType(resultSet.getString("CAR_TYPE"));
	         carVO.setMemberID(resultSet.getString("MEMBER_ID"));
	         carVO.setCreatedDate(resultSet.getString("CREATE_DATE"));
	         carVO.setUpdatedDate(resultSet.getString("UPDATE_DATE"));
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            if(resultSet != null) {
	               resultSet.close();
	            }
	            if(preparedStatement != null) {
	               preparedStatement.close();
	            }
	            if(connection != null) {
	               connection.close();
	            }
	         } catch (SQLException e) {
	            throw new RuntimeException();
	         }
	      }
	      return carVO;
	   }
	   
//  수정하기
  public void update(CarVO carVO) {
     String query = "UPDATE TBL_CAR "
    		 + "SET CAR_NAME=?, CAR_BRAND=?, CAR_TYPE=?, "
    		 + "MEMBER_ID=?, WHERE ID=? ";
     
     try {
        connection = Configuration.getConnection();
        preparedStatement = connection.prepareStatement(query);
        
        connection = Configuration.getConnection();
        preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, carVO.getCarName());
        preparedStatement.setString(2, carVO.getCarBrand());
        preparedStatement.setString(3, carVO.getCarType());
        preparedStatement.setString(4, carVO.getMemberID());
        preparedStatement.setLong(5, carVO.getId());
        
        preparedStatement.executeUpdate();
        
     } catch (SQLException e) {
        e.printStackTrace();
     } finally {
        try {
           if(preparedStatement != null) {
              preparedStatement.close();
           }
           if(connection != null) {
              connection.close();
           }
        } catch (SQLException e) {
           throw new RuntimeException();
        }
     }
  }
  
//삭제하기
public void delete(Long id) {
   String query = "DELETE FROM TBL_CAR WHERE ID = ?";
   
   try {
      connection = Configuration.getConnection();
      preparedStatement = connection.prepareStatement(query);
      
      preparedStatement.setLong(1, id);
      
      preparedStatement.executeUpdate();
      
   } catch (SQLException e) {
      e.printStackTrace();
   } finally {
      try {
         if(preparedStatement != null) {
            preparedStatement.close();
         }
         if(connection != null) {
            connection.close();
         }
      } catch (SQLException e) {
         throw new RuntimeException();
      }
   }
}	

//전체 조회하기
public ArrayList<CarVO> selectAll() {
 ArrayList<CarVO> car = new ArrayList<CarVO>();
 CarVO carVO = null;
 String query = "SELECT ID, CAR_NAME, CAR_BRAND, CAR_TYPE, "
       + "MEMBER_ID, FROM TBL_CAR";
 
 try {
    connection = Configuration.getConnection();
    preparedStatement = connection.prepareStatement(query);
    
    resultSet = preparedStatement.executeQuery();
    
    if(resultSet.next()) {
       do {
    	   carVO = new CarVO();
    	   carVO.setId(resultSet.getLong("ID"));
    	   carVO.setCarName(resultSet.getString("CAR_NAME"));
	       carVO.setCarBrand(resultSet.getString("CAR_BRAND"));
	       carVO.setCarType(resultSet.getString("CAR_TYPE"));
	       carVO.setMemberID(resultSet.getString("MEMBER_ID"));
	       carVO.setCreatedDate(resultSet.getString("CREATED_DATE"));
	       carVO.setUpdatedDate(resultSet.getString("UPDATED_DATE"));
          
          car.add(carVO);
          
       } while(resultSet.next());
    }
    
 } catch (SQLException e) {
    e.printStackTrace();
 } finally {
    try {
       if(resultSet != null) {
          resultSet.close();
       }
       if(preparedStatement != null) {
          preparedStatement.close();
       }
       if(connection != null) {
          connection.close();
       }
    } catch (SQLException e) {
       throw new RuntimeException();
    }
 }
 return car;
}	
	
	
	
	
	
	
}
