package methodPractice;

public class Methodpractice {
	
//   1 ~ 10까지 println()으로 출력하는 메소드
		
	
//   "홍길동"을 n번 println()으로 출력하는 메소드		
		
		
//   이름을 n번 println()으로 출력하는 메소드		
		
		
//   세 정수의 뺄셈 메소드	
		
//   두 정수의 나눗셈 후 몫과 나머지 두 개를 구하는 메소드
	
	
//   return 값은 반드시 1개만 가능하다.	
		
	
//	 1 ~ n 까지의 합을 구해주는 메소드		
		
		
//	 홀수를 짝수로, 짝수를 홀수로 바꿔주는 메소드	
		
		
//	 문자열을 입력받고 소문자는 대문자로, 대문자는 소문자로 바꿔주는 메소드	
		
		
//	 한글을 정수로 바꿔주는 메소드 (일공이사 -> 1024)
		
		
//	 정수를 한글로 바꿔주는 메소드 (1024 -> 일공이사)	
		
		
//	 5개의 정수를 입력받고 최대값과 최소값을 구해주는 메소드
		
		
//	 upgrade: 리턴타입은 void로 하되, 사용하는 부분에서 결과를 쓸 수 있어야 한다(주소를 활용!).		
		
			
			
			
			
	public static void main(String[] args) {
		Methodpractice methodpractice = new Methodpractice();
		
		
//		methodpractice.printFromTo10();
//		methodpractice.printHong(5);
//		methodpractice.printName("한민규",10);
//		int result = methodpractice.subtract(10, 5, 4);
//		System.out.println(result);
//		int[] result = methodpractice.divide(10, 3);
//		System.out.println(result[0]);
//		System.out.println(result[1]);
		

		
		
		
		
		
		
		
		
	}
	
}
