package castingTest;

public class Film extends Video{
	public void shake() {
		System.out.println("4D 지원");
	}
}
