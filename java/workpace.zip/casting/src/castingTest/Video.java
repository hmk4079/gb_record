package castingTest;

public class Video {}
