package castingTest;

public class Animation extends Video{
	public void printSubtitle() {
		System.out.println("자막 지원");
	}
}
